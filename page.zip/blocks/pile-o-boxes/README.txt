A Pen created at CodePen.io. You can find this one at https://codepen.io/ge1doot/pen/vEVxop.

 Continuous collision engine (speculative contacts). 
Javascript implementation based on a physics tutorial and C# code by Paul Firth. Drag and drop to create new rectangles.