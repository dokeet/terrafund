A Pen created at CodePen.io. You can find this one at https://codepen.io/ge1doot/pen/bdQXjJ.

 Don't get lost in the fractal tree!