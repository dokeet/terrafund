A Pen created at CodePen.io. You can find this one at https://codepen.io/alexandrix/pen/VbeyZO.

 Exploring the wonderful concept of Inverse Kinematics. This fork (from my original pen) uses physics: gravity, viscosity and spring effects. 